void writeArchive(FILE *archive, char option, int finalsize, int *array);
void printResult(int size, int *result);
void writeHeader(FILE *archive, char option);
void choicArchive(char option, int size, int *result);