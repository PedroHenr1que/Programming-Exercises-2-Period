void newReverse(int *array, int size);
void elemNum(int *array, int size, int num);
void unique(int *array, int size);
void deleteN(int *array, int size, int n);